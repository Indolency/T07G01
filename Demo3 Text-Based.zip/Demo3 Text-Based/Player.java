import java.util.ArrayList;
/**
 * This Player class stores the playerName, board, and player's countriesOwned
 * @version 4.0
 * @author
 * @since 2019-03-2
 */
public abstract class Player{

  protected String playerName;
  protected Board board;
  protected ArrayList<Country> countriesOwned = new ArrayList<Country>();
  protected boolean winner = false;


  /**
   * Constructs the Player instance using the specified name and points it to
   * main board in Game
   * @param name String that represents the player's name
   * @param board Board that represents the Board found in main in Game
   */
  public Player(String name, Board board){
    setPlayerName(name);
    setBoard(board);
  }

  /**
   * Getter and Setter methods
   */

  protected String getPlayerName(){
    return playerName;
  }

  protected Board getBoard(){
    return board;
  }

  protected ArrayList<Country> getCountriesOwned(){
    return countriesOwned;
  }

  protected boolean getWinner() {
    return winner;
  }

  protected void setPlayerName(String name){
    playerName = name;
  }

  protected void setBoard(Board board){
    this.board = board;
  }

  protected void setCountriesOwned(ArrayList<Country> list){
    countriesOwned = list;
  }

  protected void setWinner(boolean winLose) {
    winner = winLose;
  }

  /**
   * Adds an individual country to the countriesOwned ArrayList
   * @param country Country on the main board in Game that is assigned to this player
   */
  protected void addCountry(Country country){
    countriesOwned.add(country);
  }

  protected void removeCountry(Country country){
    countriesOwned.remove(country);
  }

  /**
   * This method is overridden in the children classes: HumanPlayer and AIPlayer
   */
  protected void draft(){
  }

  /**
   * This method is overridden in the children classes: HumanPlayer and AIPlayer
   */
  protected void attack(){
  }

  /**
   * This method is overridden in the children classes: HumanPlayer and AIPlayer
   */
  protected void fortify(){
  }

  /**
   * Determines the number of troops a player will be able to draft with in the beginning of each turn
   * @return n is an integer that represents the number of troops each player can draft with
   */
  protected int draftNum(){
    int enggCounter = 0;
    int knesCounter = 0;
    int scienceCounter = 0;
    int artsCounter = 0;
    int pfCounter = 0;
    int resCounter = 0;
    int n = getCountriesOwned().size() / 3;
    if (n<3)
      n = 3;
    int continentnum = 0;
    for(int i=0; i<getCountriesOwned().size(); i++) {
      continentnum = getCountriesOwned().get(i).getContinent();
      switch (continentnum) {
        case 0:
          enggCounter += 1;
          break;

        case 1:
          knesCounter += 1;
          break;

        case 2:
          scienceCounter += 1;
          break;

        case 3:
          artsCounter += 1;
          break;

        case 4:
          pfCounter += 1;
          break;

        case 5:
          resCounter += 1;
          break;
      }

    }

    if (enggCounter == 8) {
      n += 5;
      System.out.println("5 extra troops for conqouring the continent ENGG");
    }

    if (knesCounter == 5) {
      n += 3;
      System.out.println("3 extra troops for conqouring the continent KNES");
    }

    if (scienceCounter == 10) {
      n += 7;
      System.out.println("7 extra troops for conqouring the continent SCIENCE");
    }

    if (artsCounter == 9) {
      n += 5;
      System.out.println("5 extra troops for conqouring the continent ARTS");
    }

    if (pfCounter == 4) {
      n += 2;
      System.out.println("2 extra troops for conqouring the continent PF");
    }

    if (resCounter == 5) {
      n += 2;
      System.out.println("2 extra troops for conqouring the continent REZ");
    }

    return n;
  }
}
