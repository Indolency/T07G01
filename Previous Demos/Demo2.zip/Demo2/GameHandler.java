import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.control.*;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import java.io.File;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.geometry.*;
import java.util.*;
import javafx.scene.image.*;
import javafx.scene.paint.Color;
import javafx.beans.binding.Bindings;
import javafx.scene.*;
import javafx.scene.effect.*;

import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 * This GameHandler class runs the game with graphics.
 * @version 1.0
 * @author T07G01
 * @since 2019-03-12
 */
public class GameHandler extends Application{

  private Stage generalStage = new Stage();
  private static int numOfPlayers;
  private static ArrayList<String> playerNames = new ArrayList<String>();
  private static ArrayList<String> playerTypes = new ArrayList<String>();
  private static Player currentPlayer;
  private Board board;
  private GameConfig gameConfig;
  private Game game;
  private MapSetup map = new MapSetup();



  @Override
  public void start(Stage primaryStage){
    Board theBoard = new Board();
    GameConfig theGameConfig = new GameConfig();
    Game theGame = new Game(theBoard, theGameConfig);
    theGameConfig.setGame(theGame);

    setBoard(theBoard);
    setGameConfig(theGameConfig);
    setGame(theGame);

    startMenu();
  }

  public GameConfig getGameConfig(){
    return gameConfig;
  }

  public Game getGame(){
    return game;
  }

  public void setGame(Game game1){
    game = game1;
  }

  public void setBoard(Board board1){
    board = board1;
  }

  public void setGameConfig(GameConfig gameConfig1){
    gameConfig = gameConfig1;
  }

  public void setCurrentPlayer(Player player){
    currentPlayer = player;
  }

  public Player getCurrentPlayer(){
    return currentPlayer;
  }

/**
 * The beginning of the game,shwos the title, asks the user for the nubmer of players.
 * Stores the input from the player to set up the next scene.
 */
  public void startMenu(){
    VBox welcome = new VBox();
    ComboBox<Integer> numPlayers = new ComboBox<Integer>();
    numPlayers.getItems().addAll(2,3,4,5,6);
    Button OKButton = new Button("OK");

    welcome.getChildren().add(new Label("Conquering U of C!"));
    welcome.getChildren().add(new Label("How many players would you like?"));
    welcome.getChildren().add(numPlayers);
    welcome.getChildren().add(OKButton);
    welcome.setAlignment(Pos.CENTER);
    welcome.setSpacing(5);

    Scene welcomeScene = new Scene(welcome, 300, 150);
    generalStage.setScene(welcomeScene);
    generalStage.show();

    OKButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        numOfPlayers = numPlayers.getValue();
		System.out.println(numOfPlayers);
		playerOptions();

      }
    });
	}

/**
 * Shows same number of textfields as players in the game to take in the player
 * names and set the player type (either human or AI).
 */
  public void playerOptions(){

	ArrayList<TextField> names = new ArrayList<TextField>();
	ArrayList<ComboBox> types = new ArrayList<ComboBox>();

	VBox playerBoxes = new VBox();
	HBox header = new HBox();
	header.getChildren().addAll(new Label("Player Name"), new Label("Player Type"));
	header.setSpacing(150);
	playerBoxes.getChildren().add(header);

	for (int i=0; i<numOfPlayers; i++){
		HBox player = new HBox();
		TextField name = new TextField();
		ComboBox<String> type = new ComboBox<String>();
		type.getItems().addAll("HUMAN", "AI");

		names.add(name);
		types.add(type);

		player.getChildren().addAll(name, type);
		player.setSpacing(50);
		player.setAlignment(Pos.CENTER);

		playerBoxes.getChildren().add(player);
		playerBoxes.setSpacing(10);
	}

	Button startButton = new Button("Start!");
	playerBoxes.getChildren().add(startButton);

	Scene playerScene = new Scene(playerBoxes, 400, 75*numOfPlayers);
	generalStage.setScene(playerScene);
	generalStage.show();

	startButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event){
		    for (int i=0;i<numOfPlayers;i++){
    			playerNames.add(names.get(i).getText());
    			playerTypes.add(types.get(i).getValue().toString());
    		}
        System.out.println(playerNames.get(0) + playerTypes.get(0));
        gameConfig.createPlayers(playerNames, playerTypes);
        gameConfig.boardSetup();
    		playGame();
    	  }
        });
      }

/**
 * The main window of the game.
 */
 public void playGame(){
   boolean notWon = true;

   while(notWon){
     for(Player player: gameConfig.getListOfPlayers()){
       setCurrentPlayer(player);
       turnHandle();
     }
   }
   /**
   // Draft country selection
   VBox draft = new VBox();
   Button draftButton = new Button("Draft");
   ComboBox<String> countries1 = draftComboBox();
   draft.getChildren().addAll(countries1, draftButton);
   draft.setAlignment(Pos.CENTER);
   draft.setSpacing(10);

   // Attack country selection
   VBox attack = new VBox();
   Button attackButton = new Button("Attack");
   ComboBox<String> countries2 = new ComboBox<String>();
   attack.getChildren().addAll(countries2, attackButton);
   attack.setAlignment(Pos.CENTER);
   attack.setSpacing(10);

   // Fortify country selection
   VBox fortify = new VBox();
   Button fortifyButton = new Button("Fortify");
   ComboBox<String> countries3 = new ComboBox<String>();
   fortify.getChildren().addAll(countries3, fortifyButton);
   fortify.setAlignment(Pos.CENTER);
   fortify.setSpacing(10);

   // Adding all phases into HBox
   HBox playButtons = new HBox();
   playButtons.getChildren().addAll(draft, attack, fortify);
   playButtons.setAlignment(Pos.CENTER);
   playButtons.setSpacing(250);

   VBox gameWindow = new VBox();
   Button quitButton = new Button("Quit");
   map.setupCountryImages();
   map.setupCountryImageNames();
   map.updateCountryImageViews(gameConfig.getListOfPlayers());

   gameWindow.getChildren().add(map.setupMap());
   gameWindow.getChildren().add(playButtons);
   gameWindow.getChildren().add(quitButton);
   gameWindow.setAlignment(Pos.CENTER);
   gameWindow.setSpacing(20);

   Scene gameScene = new Scene(gameWindow, 1000, 800);
   generalStage.setScene(gameScene);
   generalStage.show();

   // Closes the game when the quit button is pressed
   quitButton.setOnAction(new EventHandler<ActionEvent>() {
     @Override
     public void handle(ActionEvent event){
       generalStage.close();
     }
   });

   // Adds troops to country selected
   draftButton.setOnAction(new EventHandler<ActionEvent>() {
     @Override
     public void handle(ActionEvent event){
     }
   });

   */
 }

   public void turnHandle(){
     VBox gameWindow = new VBox();

     Text textHeading= new Text("CONQUERING U OF C");
     Text textPhase = new Text("Draft Phase");
     Text textPlayer = new Text("It is "+getCurrentPlayer().getPlayerName()+"'s turn.");
     textHeading.setX(500);
     textHeading.setY(110);
     textHeading.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
     textPhase.setX(500);
     textPhase.setY(200);
     textPhase.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 30));
     textPlayer.setX(500);
     textPlayer.setY(250);
     textPlayer.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));

     map.setupCountryImages();
     map.setupCountryImageViews();
     map.updateCountryImageViews(gameConfig.getListOfPlayers(), board.getCountriesList());

     Button draftButton = new Button("Draft");
     ComboBox<String> draftCountries = draftComboBox();

     gameWindow.getChildren().addAll(textHeading, textPhase, textPlayer, map.setupMap(), draftCountries, draftButton);
     gameWindow.setAlignment(Pos.CENTER);
     gameWindow.setSpacing(10);
     Scene gameScene = new Scene(gameWindow, 1000, 800);
     generalStage.setScene(gameScene);
     generalStage.show();

     draftButton.setOnAction(new EventHandler<ActionEvent>() {
       @Override
       public void handle(ActionEvent event){
         String selectedDraft = draftCountries.getValue().toString();
         Player player = getCurrentPlayer();
         player.draft(selectedDraft);
         game.getGameBoard().showBoard();

         generalStage.close();
         attackHandle();
       }
     });
   }

   /**
   * Creates a ComboBox of the current player's possessed countries.
   * @return
   */
   public ComboBox<String> draftComboBox(){
     ComboBox<String> toReturn = new ComboBox<String>();
     for (int i=0; i< getCurrentPlayer().getCountriesOwned().size(); i++){
       toReturn.getItems().add(getCurrentPlayer().getCountriesOwned().get(i).getCountryName());
     }
     return toReturn;
   }

   public void attackHandle(){
     VBox gameWindow = new VBox();

     Text textHeading= new Text("CONQUERING U OF C");
     Text textPhase = new Text("Attack Phase");
     Text textPlayer = new Text("It is "+getCurrentPlayer().getPlayerName()+"'s turn.");
     textHeading.setX(500);
     textHeading.setY(110);
     textHeading.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
     textPhase.setX(500);
     textPhase.setY(200);
     textPhase.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 30));
     textPlayer.setX(500);
     textPlayer.setY(250);
     textPlayer.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));

     Button attackButton = new Button("Attack");

     gameWindow.getChildren().addAll(textHeading, textPhase, textPlayer, attackButton);
     gameWindow.setAlignment(Pos.CENTER);
     gameWindow.setSpacing(10);
     Scene gameScene = new Scene(gameWindow, 1000, 800);
     generalStage.setScene(gameScene);
     generalStage.show();

     attackButton.setOnAction(new EventHandler<ActionEvent>() {
       @Override
       public void handle(ActionEvent event){
         generalStage.close();
         fortifyHandle();
       }
   });
 }

   public void fortifyHandle(){
     VBox gameWindow = new VBox();

     Text textHeading= new Text("CONQUERING U OF C");
     Text textPhase = new Text("Fortify Phase");
     Text textPlayer = new Text("It is "+getCurrentPlayer().getPlayerName()+"'s turn.");
     textHeading.setX(500);
     textHeading.setY(110);
     textHeading.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 40));
     textPhase.setX(500);
     textPhase.setY(200);
     textPhase.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 30));
     textPlayer.setX(500);
     textPlayer.setY(250);
     textPlayer.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));

     Button fortifyButton = new Button("Fortify");

     gameWindow.getChildren().addAll(textHeading, textPhase, textPlayer, fortifyButton);
     gameWindow.setAlignment(Pos.CENTER);
     gameWindow.setSpacing(10);
     Scene gameScene = new Scene(gameWindow, 1000, 800);
     generalStage.setScene(gameScene);
     generalStage.show();

     fortifyButton.setOnAction(new EventHandler<ActionEvent>() {
       @Override
       public void handle(ActionEvent event){
         generalStage.close();
       }
   });
   }

   public void resultHandle(){
   }


public static void main(String[] args){
  launch(args);
}

}
