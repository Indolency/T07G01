/**
 *
 * @version
 * @author
 * @since
 */
 
public class Turn{

  public Turn(){
    }

}
