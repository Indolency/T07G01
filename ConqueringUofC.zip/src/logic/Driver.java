package logic;

import controllers.WelcomeWindowController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;

/**
 * This Driver class is part of the Risk game that is responsible
 * for allowing the code of the logic to communicate with the
 * code that displays to the user. It also contains the main
 * start method that initializes the game.
 * @version 2.0
 * @author T07G01
 * @since 2019-04-10
 */

public class Driver extends Application implements Serializable {

    /**
     * This is how all the frontend FXML files connects to the backend
     */
    private GameConfig gameConfig;
    private boolean playing = true;

    /**
     * Setter and Getter methods
     */
    public GameConfig getGameConfig() {
        return gameConfig;
    }

    public void setGameConfig(GameConfig gameConfig) {
        this.gameConfig = gameConfig;
    }


    /**
     * 1. Creates the appropriate objects and connects it to the driver
     * and also sets the this Driver to the appropriate objects created
     * 2. Loads the first FXML file to display
     *
     * @param primaryStage the stage the will display the scenes for the game
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
       // do {
            GameConfig theGameConfig = new GameConfig(this);
            setGameConfig(theGameConfig);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/welcomeWindow.fxml"));
            Parent root = loader.load();
            WelcomeWindowController controller = loader.getController();
            controller.setDriver(this);

            primaryStage.setTitle("Conquering U of C");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
    }

    public void restart(Stage primaryStage) throws Exception {
        GameConfig theGameConfig = new GameConfig(this);
        setGameConfig(theGameConfig);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/welcomeWindow.fxml"));
        Parent root = loader.load();
        WelcomeWindowController controller = loader.getController();
        controller.setDriver(this);

        primaryStage.setTitle("Conquering U of C");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void writeObjectToFile(){
        final String filepath="savedGame";
        try{
            FileOutputStream fileOut = new FileOutputStream(filepath);
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(gameConfig);
            objectOut.close();
            System.out.println("IT's been saved!");
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public GameConfig readObjectFromFile(String filepath) {
        try {

            FileInputStream fileIn = new FileInputStream(filepath);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);

            GameConfig loadedGameConfig = (GameConfig) objectIn.readObject();

            System.out.println("The Object has been read from the file");
            objectIn.close();
            setGameConfig(loadedGameConfig);
            return loadedGameConfig;

        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("nope");
            return null;
        }
    }

}