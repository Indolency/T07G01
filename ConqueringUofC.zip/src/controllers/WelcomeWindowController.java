package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;
import logic.Country;
import logic.Driver;
import logic.Player;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class WelcomeWindowController implements Initializable {

    @FXML
    private ChoiceBox<Integer> numOfPlayersChoiceBox;

    private Driver driver;

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public void startGameButtonClicked(ActionEvent event) throws IOException {
        Object num = numOfPlayersChoiceBox.getSelectionModel().getSelectedItem();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/createPlayers.fxml"));
        Parent createPlayersParent = loader.load();
        CreatePlayersController controller = loader.getController();
        controller.fillWelcomeVBox((int) num);
        controller.setDriver(getDriver());

        Scene createPlayerScene = new Scene(createPlayersParent);
        Stage createPlayerStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        createPlayerStage.setScene(createPlayerScene);
    }

    public void loadGameButtonClicked(ActionEvent event) throws IOException{
        final String filepath="savedGame";
        getDriver().readObjectFromFile(filepath);

        getDriver().getGameConfig().getBoard().showBoard(); // Shows board in text

        // Loads the map FXML and changes scene
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/map.fxml"));
        Parent mapParent = loader.load();
        MapController controller = loader.getController();
        controller.setDriver(getDriver());

        Player currentPlayer = getDriver().getGameConfig().getListOfPlayers().get(0);
        getDriver().getGameConfig().setCurrentPlayer(currentPlayer);
        getDriver().getGameConfig().getCurrentPlayer().setDraftNumLeft(getDriver().getGameConfig().getCurrentPlayer().draftNum());

        Scene mapScene = new Scene(mapParent);
        Stage createPlayerStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        controller.updatePlayerName(currentPlayer);


        // Loops through visually set up the map with colours
        for (int i=0; i<41; i++){
            Country country = getDriver().getGameConfig().getBoard().getCountriesList().get(i); // Gets the current country to colour
            String countryName = country.getCountryName();
            int numOfTroops = country.getNumOfTroops();
            int num = getDriver().getGameConfig().getListOfPlayers().indexOf(country.getPlayerPossession()); // Gets current player number
            controller.updateCountry(countryName, numOfTroops, num); // Depending on the country and current player, will colour
        }

        createPlayerStage.setScene(mapScene);
        createPlayerStage.setMaximized(true);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<Integer> numOfPlayersList = FXCollections.observableArrayList(2,3,4,5,6);
        numOfPlayersChoiceBox.setValue(2);
        numOfPlayersChoiceBox.setItems(numOfPlayersList);
    }

}